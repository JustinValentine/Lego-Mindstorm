from driver import RoboticArm


arm = RoboticArm()
# arm.draw_line(0.15, 0, 0, 0.15)
# arm.draw_line(0.1, 0, 0.05, 0.1)
# arm.draw_line(0.15, 0, -0.1, 0.1)
arm.draw_line(0.12, 0.15, 0, 0.15)